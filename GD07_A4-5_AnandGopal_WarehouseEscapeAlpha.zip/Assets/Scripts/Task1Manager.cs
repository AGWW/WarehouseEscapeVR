using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Task1Manager : MonoBehaviour
{
    public Light[] lights; // Assign the light components for each of the 5 boxes in the inspector
    public Light finalLight; // Assign the final light component in the inspector
    public Color greenLightColor; // Set this color to green in the inspector
    public Color redLightColor; // Set this color to red in the inspector
    public Color whiteLightColor; // Set this color to white in the inspector
    private bool[] answers = new bool[5]; // To store the player's answers: false for No, true for Yes
    public GameObject demotext;

    // Method called when the No button is pressed for a box
    public void AnswerNo(int boxNumber)
    {
        SetLightColor(boxNumber - 1, false); // Set the light to red
        answers[boxNumber - 1] = false; // Store the answer
    }

    // Method called when the Yes button is pressed for a box
    public void AnswerYes(int boxNumber)
    {
        SetLightColor(boxNumber - 1, true); // Set the light to green
        answers[boxNumber - 1] = true; // Store the answer
    }

    // Sets the light color above the box
    private void SetLightColor(int lightIndex, bool isYes)
    {
        lights[lightIndex].color = isYes ? greenLightColor : redLightColor;
    }

    // Called when the final submit button is pressed
    public void SubmitAnswers()
    {
        // Check if the answers match the correct sequence: No, Yes, Yes, No, No
        if (!answers[0] && answers[1] && answers[2] && !answers[3] && !answers[4])
        {
            StartCoroutine(IndicateFinalAnswer(true)); // All answers are correct
        }
        else
        {
            StartCoroutine(IndicateFinalAnswer(false)); // Not all answers are correct
        }
    }

    // Sets the final light color for 2 seconds and then reverts to white
    IEnumerator IndicateFinalAnswer(bool isCorrect)
    {
        if (isCorrect == true)
        {
            finalLight.color = greenLightColor;
            demotext.SetActive(true);
        }
        else
        {
            finalLight.color = redLightColor;
            yield return new WaitForSeconds(2);
            finalLight.color = whiteLightColor;
        }
    }

    // Called when all answers are correct (Optional based on your game's logic)
    private void TaskComplete()
    {
        Debug.Log("Task Completed Successfully!");
        // Implement the logic for task completion (e.g., unlocking a door, revealing a hidden item, etc.)
    }
}
