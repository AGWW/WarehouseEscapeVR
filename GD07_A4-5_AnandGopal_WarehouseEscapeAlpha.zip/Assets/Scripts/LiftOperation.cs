using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LiftOperation : MonoBehaviour
{
    public float speed = 5.0f; // The speed at which the lift moves
    private bool isMoving = false;
    private Vector3 targetPosition;

    private void Update()
    {
        if (isMoving)
        {
            // Move our position a step closer to the target.
            float step = speed * Time.deltaTime; // calculate distance to move
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, step);

            // Check if the position of the lift and target position are approximately equal.
            if (Vector3.Distance(transform.position, targetPosition) < 0.001f)
            {
                transform.position = targetPosition; // Ensure the lift is exactly at the target position
                isMoving = false; // Stop the lift from moving
            }
        }
    }

    // Public method to move the lift to the ground level
    public void MoveToGroundLevel()
    {
        StartMovingTo(new Vector3(transform.position.x, 0.28f, transform.position.z));
    }

    // Public method to move the lift to level 1
    public void MoveToLevel1()
    {
        StartMovingTo(new Vector3(transform.position.x, 12.28f, transform.position.z));
    }

    // Public method to move the lift to level 2
    public void MoveToLevel2()
    {
        StartMovingTo(new Vector3(transform.position.x, 20.28f, transform.position.z));
    }

    // Public method to move the lift to level 3
    public void MoveToLevel3()
    {
        StartMovingTo(new Vector3(transform.position.x, 28.28f, transform.position.z));
    }

    // Helper method to start the movement
    private void StartMovingTo(Vector3 newPosition)
    {
        if (!isMoving || transform.position != targetPosition) // Check if the lift is not already moving or is not at the target position
        {
            targetPosition = newPosition;
            isMoving = true;
        }
    }
    
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player")) // Make sure your character has the tag "Player"
        {
            other.transform.parent = transform; // Set the lift as the parent of the character
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            other.transform.parent = null; // Remove the parent-child relationship
        }
    }
}
